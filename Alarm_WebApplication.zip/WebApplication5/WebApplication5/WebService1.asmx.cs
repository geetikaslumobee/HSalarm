﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication5
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {


        public Queue HelloWorld()
        {
            Class1 class1 = new Class1();
            Queue q = new Queue();
            Queue q1 = new Queue();
            Random rnd = new Random();
            float temp = rnd.Next(40, 100);
            class1.id = "ABCD";
            class1.Name = temp;
            q.Enqueue(class1);
            q1.Enqueue(temp);
            return q1;
        }

        [WebMethod]
        public void generate()
        {
            Queue q = (Queue)HelloWorld();
        }

      
        [WebMethod]
        public String HelloWorld2()
        {
            Queue q1 = (Queue)HelloWorld();
            Queue q = new Queue();
            String i = null;

            i = "" + q1.Dequeue();
            Class2 class2 = new Class2();
            Class1 class1 = new Class1();
            class2.id = "ABCD";
            class2.Name = i;

            if (Convert.ToDouble(i) > 80)
            {
                q.Enqueue(class1);
            }

            return i;
        }
    }
}
