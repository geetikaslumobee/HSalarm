﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             if (TextBox1.Text == "start")
            {
                WebApplication5.WebService1 w = new WebApplication5.WebService1();
                Label1.Text = w.HelloWorld2();
                if (Convert.ToInt32(w.HelloWorld2()) > 80)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Temperarture was grater than 80F');</script>");
            }
            }

            if (TextBox1.Text == "stop")
            {

            }         
        }
    }
}